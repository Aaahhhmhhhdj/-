✟︙لتنصيب سورس بلأگ ، YOUSSRY ،

• ┉ • ┉ • ┉ • ┉ • ┉ • ┉ • ┉ •
         
✟︙ اتبع الخطوات ادناه :-


✟︙ انسخ الكود وضعه في الترمنال ،

✟︙ الكود ،

git clone https://github.com/TEAMYOUSSRY/YOUSSRY.git && cd YOUSSRY  && chmod +x tg && chmod +x RUNFA.sh && chmod +x FA && ./RUNFA.sh

• ┉ • ┉ • ┉ • ┉ • ┉ • ┉ • ┉ •

✟︙راح يطلب المعلومات التاليه :- 

✟︙{ ايدي المطور  • معرف المطور • توكن البوت } ،

✟︙قم بادخال معلوماتك سوف يعمل تلقائيا ،

• ┉ • ┉ • ┉ • ┉ • ┉ • ┉ • ┉ •

✟︙كود الرن ، 

killall screen;cd YOUSSRY;./FA

✟︙كود الحذف ، 

rm -rf YOUSSRY

• ┉ • ┉ • ┉ • ┉ • ┉ • ┉ • ┉ •

✟︙للاستفسار واضافه الافكار  🔽

مبرمج السورس @I_E_S_M

قناه السورس @black_mariem

كروب الدعم  https://t.me/cafe_elsoo7ab
